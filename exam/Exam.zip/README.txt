Exam in Numerical Methods

This exercise aims to investigate the convergence rates of some interesting integrals in different dimensions as function of the number of sample points. This will be done using multidimensional pseudo-random (also known as plain Monte Carlo) and quasi-random (also known as Halton and/or lattice sequence) integrators.

Along with .c-files comes a file named data. It contains N, calculated and the actual result. The two latter comes with error-estimation.

Have a fantastic summer, Dmitri!
